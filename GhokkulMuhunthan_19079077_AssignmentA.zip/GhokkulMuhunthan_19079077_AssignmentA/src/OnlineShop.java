/* Java Program to design the main properties of the OnlineShop.
   Name: Ghokkul Muhunthan 
   Student ID: 19079077
 */

public class OnlineShop //Name of the class.
{	
		//Initializing a String array to produce an Online inventory shop.
		String[] inventory = {"Corolla , Toyota, $2000, B+, 4.425417", 
							  "Dart, Dodge, $500, A-, 3.79",
							  "Focus, Ford, $1500, C+, 2.85",
							  "250z, Nissan, $6000, A+, 5",
							  "PT Crusier Convertible, Chrysler, $500, C-, 0.0"};
		int nProduct = 0;
		
		//Method showing nProduct is set to zero.
		public OnlineShop()
		{
			 nProduct = 0;
		}
		
		//Method showing when nProduct has to be less than 5.
		public void add()
		{
			if(nProduct <5)
			{
				nProduct = nProduct + 1; 	
			}
		}
		
		// toString method for OnlineShop class.
		public String toString()
		{
			// Initializes String variable to a title.
			String message = "Contents of the Inventory\n";
		
			// For loop to add (concatenate) sentences to the String variable message.
			for(int index = 0; index < this.inventory.length; index++)
			{
				// Concatenates the String variable with (index number + 1) and calls the Inventory toString method.
				message += (((index + 1) + ". " + this.inventory[index].toString() + "\n"));
			}
			
			System.out.println(message);
			// Returns completed message to caller.
			return message;
		}
}

