/* Java Program to show on console the full function of ShopApp.
 * Name: Ghokkul Muhunthan 
 * Student ID: 19079077
 */

import java.util.*;
public class ShopApp  //Name of the class.
{
	public static void main(String[] args) 
	{
		//Defining variables of the ShopApp class.
	 	String answer; //Terminate the program when the user presses C.
		int search; //Search for an specific item in the inventory.
		char choice; //Choice whether to continue the program or end the program.
		Scanner userInput; //creates an object for the scanner. 
		
		do
		{
			//Prints on console the message followed by each of the options given by the user.
			System.out.println("+-------------------------------------------+");
			System.out.println("|  Please select an option to choose from?  |");
			System.out.println("+-------------------------------------------+");
			System.out.println("A. Display inventory");
			System.out.println("B. Rate Product");
			System.out.println("C. Exit");
			
			//Get user's choice 
			System.out.println("Please make a selection.");
			//creates an object of Scanner
			userInput = new Scanner(System.in);
			
			//takes input from the keyboard
			choice = userInput.next().charAt(0);
			
			//Condition A offers the user to show the contents of the inventory. 
			if(choice == 'A')
			{
				String message = "Contents of the Inventory\n";
				
				OnlineShop displayinventory = new OnlineShop(); 
				for(int index = 0; index < displayinventory.inventory.length; index++)
				{
					// Concatenates the String variable with (index number + 1) and calls the Inventory toString method.
					message += (((index + 1) + ". " + displayinventory.inventory[index].toString() + "\n"));
				}
				
				System.out.println(message); //Prints message
			}	
			//Condition B offers the user to select the product from the inventory
			//the asks the user to rate the item of the product the user have selected.
			else if (choice == 'B')
			{	
				//1.Prints the OnlineShop toString to the console.
				OnlineShop displayinventory = new OnlineShop(); 
				String message = "Test to see inventory\n"; 
				//2. Ask the user to select a product by typing number 1 to 5.		
				System.out.println("Select an inventory item from 1 to 5!");
				//creates an object of Scanner
				Scanner enterinventoryitem = new Scanner(System.in);
				int displayinventoryitem = enterinventoryitem.nextInt();

				//If display inventory item is less than 1 and display inventory item
				//is greater than 5. It is a invalid numerical value.
				if(displayinventoryitem  > 5 || displayinventoryitem  < 0)
				{
					System.out.println("This is an in-valid entry item!");
					System.out.println("Please try again!");			
				}		
				
				//2. Ask the user to select a product by typing number 1 to 5.
				System.out.println(message);
				if(displayinventoryitem > 0 && displayinventoryitem < 6)
				{
					System.out.println("This is an valid entry item!");
				
					//Display Inventory Item user has select and it will minus 1 from it.
					//For example this array is set to 5. But we want it as the original 
					//number as it given.
					System.out.println("Display Inventory Item: "+displayinventoryitem);
					System.out.println(displayinventory.inventory[displayinventoryitem-1]); 
				}
			}
			//Condition C offers the user to terminate the program fully.
			//It will also asks the user do you want to try this program again?
			else if (choice == 'C')
			{
				//Asks the user to terminate the program?
				System.out.println("Press C to terminate the program");
				String answer1 = userInput.next();
				System.out.println("Input: "+answer1);
				// Outputs farewell message.	
				System.out.println("\n===========================================");
				System.out.println("|      Thank you for using OnlineShop        |");
				System.out.println("|    We hope you had a wonderful time.       |");
				System.out.println("|            Have a nice day.                |");
				System.out.println("===========================================");
				System.out.println("Do you want to try again? Yes or No");
				choice = userInput.next().charAt(0);
				
				//If condition when the user enters No it will go inside the condition
				//and produce an output message to let the user know the program has 
				//successfully ended. 
				if(choice == 'n' || choice == 'N')
				{
					System.out.println("Goodbye!");
					break; //breaks the program. 
				}
			}
		} 	while(1==1);
		//do while line statement above shows the user when you enter either those characters C will terminate the program.
		//YES will continue the program. NO will stop the program.
		
		//Closes scanner
		userInput.close();
	}
}
