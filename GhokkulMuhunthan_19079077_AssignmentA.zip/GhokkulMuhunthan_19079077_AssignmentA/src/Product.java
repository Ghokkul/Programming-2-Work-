/* Java Program to illustrate the Products to design the ShopApp class.
 * Name: Ghokkul Muhunthan 
 * Student ID: 19079077
 */

public class Product //Name of the class.
{	
	//Defining The Instance Variables of the Product Class.
	private String modelName; //Set model name for manufacturer name product .
	private String manufactureName;//Set name for manufacture rname company.
	private int retailPrice; //Set retail price for product.
	private char overallRating; //Overall rating for product.
	private double reliabilityRating; //reliability rating for product.
	private int numberOfConsumers; //number of consumers for this popular product.
	private int customerCount; //How many customers has purchased this product.
	private double currentReliabilityRating; //What is the present reliability rating.
	private double oldValueReliabilityRating; //Previous reliability rating of customers who has previously used this product.
	private double oldCustomerRating; //Takes in the old customer rating.
	
	//Getters
	public String getmodelname() 
	{
		return modelName;
	}
	
	public String getmanufacturername() 
	{
		return manufactureName;
	}

	public int getretailprice() 
	{
		return retailPrice;
	}

	public char getOverallrating() 
	
	{
		return overallRating;
	}

	public int getnumberofconsumers() 
	{
		return numberOfConsumers;
	}
	
	public double getOldcustomerrating() 
	{
		return oldCustomerRating;
	}


	public double getCurrentreliabilityrating() 
	{
		return currentReliabilityRating;
	}

	//Setters
	public void setmodelname(String modelName) 
	{
		this.modelName = modelName;
	}

	public void setmanufacnoturername(String manufacturerName)
	{
		this.manufactureName = manufacturerName;
	}

	public void setretailprice(int retailprice) 
	{
		this.retailPrice = retailprice;
	}

	public void setoverallrating(char overallrating)
	{
		this.overallRating = overallrating;
	}

	public double getreliabilityrating() 
	{
		return reliabilityRating;
	}

	public void setReliabilityrating(double reliabilityrating) 
	{
		this.reliabilityRating = reliabilityrating;
	}

	public void setnumberofconsumers(int numberofconsumers) 
	{
		this.numberOfConsumers = numberofconsumers;
	}
	
	public int getcustomercount() 
	{
		return customerCount;
	}

	public void setcustomercount(int customercount) 
	{
		this.customerCount = customercount;
	}
	
	public void setcurrentreliabilityrating(double currentreliabilityrating) 
	{
		this.currentReliabilityRating = currentreliabilityrating;
	}

	public void setOldcustomerrating(double oldcustomerrating) 
	{
		this.oldCustomerRating = oldcustomerrating;
	}
	
    // Constructor to initialize model name , manufacturer name and retail price.
	//Using three input parameters.
	public Product(String mdlname, String manuname, int rprice) //Input parameters of the constructors 
	{
		//Used within the constructor
		this.modelName = mdlname; //model name.
		this.manufactureName = manuname; //manufacturer name
		this.retailPrice = rprice; //retail
		this.overallRating = 'A'; //overall-rating
		this.reliabilityRating = 4.48; //reliability rating
		this.numberOfConsumers = 100; //number of consumers
	}

	// Constructor to initialize model name , manufacturer name
	//Using two input parameters.
	public void Product1(String modelname, String manufacturername)
	{
		this.modelName = modelname; //model name 
		this.manufactureName = manufacturername; //manufacturer name 
		this.retailPrice = 4000; //retail price
		this.overallRating = 'A';  //overall rating 
		this.reliabilityRating = 4.48; //reliability rating 
		this.numberOfConsumers = 100; //number of consumers 
	}
	
	//Displaying the Product Description after user has inputed.
	public void display()
	{
		System.out.println("Model Name: "+this.modelName);
		System.out.println("Manufacturer Name: "+this.manufactureName);
		System.out.println("Retail Price: "+this.retailPrice);
		System.out.println("Overall Rating: "+this.overallRating);
		System.out.println("Reliability Rating: "+this.reliabilityRating);
		System.out.println("Number of Consumers: "+this.numberOfConsumers);
	}
	
	//Method for Reliability Rating 
	public double rateReliability(double reliabilityrating)
	{
		double newvaluereliabilityrating = 0.0;	//new value reliability rating 
	
		//Customers who rated the product. Using this formula to produce the new reliability rating.
		newvaluereliabilityrating = ((oldValueReliabilityRating * customerCount) + reliabilityrating)/(customerCount + 1);
		
		customerCount++; //customer count
		return newvaluereliabilityrating;
	}
	
    // Overriding toString() method of String class	@Override
	@Override
	public String toString()
	{
		String productDescription="";
		productDescription+= " Price: " +this.getretailprice()+ "Product Rating: " + this.getOverallrating(); 
		return productDescription; 
	}
}
